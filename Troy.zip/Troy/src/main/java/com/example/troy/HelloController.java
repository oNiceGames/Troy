package com.example.troy;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.w3c.dom.events.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;
public class HelloController {

    @FXML
    private Label errorMsg;

    @FXML
    private Button loginBtn;
    @FXML
    private PasswordField passwordFiled;

    @FXML
    private TextField unTxt;

    @FXML
    void login(ActionEvent event) {
        if (unTxt.getText().isEmpty() == true || passwordFiled.getText().isEmpty() == true) {
            errorMsg.setText("Username/Password can not be empty");
            errorMsg.setVisible(true);
        } else {
            errorMsg.setText("");
        }
    }

    @FXML
    void onTextFieldClick(MouseEvent event) {

    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // This method is called when the controller is initialized
        // Hide the label when the app starts
        errorMsg.setVisible(false);
    }

    public void onTextFieldClick(javafx.scene.input.MouseEvent mouseEvent) {
        // Hide the error message
        errorMsg.setVisible(false);
    }
}